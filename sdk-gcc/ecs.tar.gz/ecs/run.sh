#!/bin/bash

./bin/ecs TrainData_2015.1.1_2015.2.19.txt input_5flavors_cpu_7days.txt output.txt
